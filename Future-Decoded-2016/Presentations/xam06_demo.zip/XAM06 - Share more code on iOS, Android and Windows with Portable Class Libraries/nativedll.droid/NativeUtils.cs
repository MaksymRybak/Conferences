﻿using System;
namespace nativedll
{
	public class NativeUtils
	{
		public static string RunNativeCode()
		{
			return "Codice nativo  Android";
		}
	}
}

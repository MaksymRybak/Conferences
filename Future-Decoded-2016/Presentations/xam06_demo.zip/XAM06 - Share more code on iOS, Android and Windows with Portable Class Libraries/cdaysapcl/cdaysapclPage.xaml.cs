﻿using nativedll;
using Xamarin.Forms;

namespace cdaysapcl
{
	public partial class cdaysapclPage : ContentPage
	{
		public cdaysapclPage()
		{
			InitializeComponent();
			lblTest.Text = NativeUtils.RunNativeCode();
		}
	}
}

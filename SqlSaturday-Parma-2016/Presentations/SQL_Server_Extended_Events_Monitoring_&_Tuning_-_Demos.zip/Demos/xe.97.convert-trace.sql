------------------------------------------------------------------------
--	Script:			xe.97.convert-trace.sql
--	Description:	Conversione da SQL Trace a Extended Events
--	Author:			Gianluca Hotz (SolidQ)
--	Copyright:		Attribution-NonCommercial-ShareAlike 3.0
--					Other copyright by original post author may apply
------------------------------------------------------------------------

------------------------------------------------------------------------
--	Setup e test funzionamento
--
--	Esempio preso da http://blogs.msdn.com/b/srgolla/archive/2013/02/13/converting-a-sql-trace-to-an-extended-event-session.aspx
--	Scaricare la DLL direttamente dal sito.
--	Attenzione: la Collation dell'istanza deve essere SQL_Latin1_General_CP1_CI_AS
------------------------------------------------------------------------

-- Attivare integrazione con CLR se non gia' attiva
EXEC sp_configure 'CLR Enabled', 1;
GO
RECONFIGURE;
GO

-- Creare un database di appoggio per l'assembly e la procedura
CREATE DATABASE TestXEvents;
GO

USE TestXEvents;
GO

-- Creare lla definizione dell'assembly
CREATE ASSEMBLY TraceToXESessionConverter
FROM 'C:\temp\TracetoXevents.dll'		-- scaricare dal sito MSDN
WITH PERMISSION_SET=SAFE
GO

-- Creare la procedura
CREATE PROCEDURE CreateEventSessionFromTrace
	@trace_id int,
	@session_name nvarchar(max)
AS
EXTERNAL NAME TraceToXESessionConverter.StoredProcedures.ConvertTraceToExtendedEvent
GO

-- Test funzionamento con il Default Trace
EXEC  CreateEventSessionFromTrace 1, 'XE_DefaultTemplateTrace';
GO

------------------------------------------------------------------------
--	Demo conversione Template Standard del Profiler.
--	Il trace deve essere in esecuzione per essere tradotto.
------------------------------------------------------------------------

------------------------------------------------------------------------
--	BEGIN Script generato dal Profiler
------------------------------------------------------------------------
-- Create a Queue
declare @rc int
declare @TraceID int
declare @maxfilesize bigint
set @maxfilesize = 5 

-- Please replace the text InsertFileNameHere, with an appropriate
-- filename prefixed by a path, e.g., c:\MyFolder\MyTrace. The .trc extension
-- will be appended to the filename automatically. If you are writing from
-- remote server to local drive, please use UNC path and make sure server has
-- write access to your network share

exec @rc = sp_trace_create @TraceID output, 0, N'C:\temp\default-template-trace', @maxfilesize, NULL 
if (@rc != 0) goto error

-- Client side File and Table cannot be scripted

-- Set the events
declare @on bit
set @on = 1
exec sp_trace_setevent @TraceID, 14, 1, @on
exec sp_trace_setevent @TraceID, 14, 9, @on
exec sp_trace_setevent @TraceID, 14, 10, @on
exec sp_trace_setevent @TraceID, 14, 11, @on
exec sp_trace_setevent @TraceID, 14, 6, @on
exec sp_trace_setevent @TraceID, 14, 12, @on
exec sp_trace_setevent @TraceID, 14, 14, @on
exec sp_trace_setevent @TraceID, 15, 11, @on
exec sp_trace_setevent @TraceID, 15, 6, @on
exec sp_trace_setevent @TraceID, 15, 9, @on
exec sp_trace_setevent @TraceID, 15, 10, @on
exec sp_trace_setevent @TraceID, 15, 12, @on
exec sp_trace_setevent @TraceID, 15, 13, @on
exec sp_trace_setevent @TraceID, 15, 14, @on
exec sp_trace_setevent @TraceID, 15, 15, @on
exec sp_trace_setevent @TraceID, 15, 16, @on
exec sp_trace_setevent @TraceID, 15, 17, @on
exec sp_trace_setevent @TraceID, 15, 18, @on
exec sp_trace_setevent @TraceID, 17, 1, @on
exec sp_trace_setevent @TraceID, 17, 9, @on
exec sp_trace_setevent @TraceID, 17, 10, @on
exec sp_trace_setevent @TraceID, 17, 11, @on
exec sp_trace_setevent @TraceID, 17, 6, @on
exec sp_trace_setevent @TraceID, 17, 12, @on
exec sp_trace_setevent @TraceID, 17, 14, @on
exec sp_trace_setevent @TraceID, 10, 9, @on
exec sp_trace_setevent @TraceID, 10, 2, @on
exec sp_trace_setevent @TraceID, 10, 10, @on
exec sp_trace_setevent @TraceID, 10, 6, @on
exec sp_trace_setevent @TraceID, 10, 11, @on
exec sp_trace_setevent @TraceID, 10, 12, @on
exec sp_trace_setevent @TraceID, 10, 13, @on
exec sp_trace_setevent @TraceID, 10, 14, @on
exec sp_trace_setevent @TraceID, 10, 15, @on
exec sp_trace_setevent @TraceID, 10, 16, @on
exec sp_trace_setevent @TraceID, 10, 17, @on
exec sp_trace_setevent @TraceID, 10, 18, @on
exec sp_trace_setevent @TraceID, 12, 1, @on
exec sp_trace_setevent @TraceID, 12, 9, @on
exec sp_trace_setevent @TraceID, 12, 11, @on
exec sp_trace_setevent @TraceID, 12, 6, @on
exec sp_trace_setevent @TraceID, 12, 10, @on
exec sp_trace_setevent @TraceID, 12, 12, @on
exec sp_trace_setevent @TraceID, 12, 13, @on
exec sp_trace_setevent @TraceID, 12, 14, @on
exec sp_trace_setevent @TraceID, 12, 15, @on
exec sp_trace_setevent @TraceID, 12, 16, @on
exec sp_trace_setevent @TraceID, 12, 17, @on
exec sp_trace_setevent @TraceID, 12, 18, @on
exec sp_trace_setevent @TraceID, 13, 1, @on
exec sp_trace_setevent @TraceID, 13, 9, @on
exec sp_trace_setevent @TraceID, 13, 11, @on
exec sp_trace_setevent @TraceID, 13, 6, @on
exec sp_trace_setevent @TraceID, 13, 10, @on
exec sp_trace_setevent @TraceID, 13, 12, @on
exec sp_trace_setevent @TraceID, 13, 14, @on


-- Set the Filters
declare @intfilter int
declare @bigintfilter bigint

exec sp_trace_setfilter @TraceID, 10, 0, 7, N'SQL Server Profiler - 1888e114-0284-43e8-8f89-b5c757b86f6d'
-- Set the trace status to start
exec sp_trace_setstatus @TraceID, 1

-- display trace id for future references
select TraceID=@TraceID
goto finish

error: 
select ErrorCode=@rc

finish: 
go
------------------------------------------------------------------------
--	END Script generato dal Profiler
--	Ricordarsi di segnare il trace ID
------------------------------------------------------------------------

--	Test conversione
EXEC  CreateEventSessionFromTrace 2,'XE_TraceStandardTemplate'
GO

-- Ricordarsi di spegnere il trace
EXEC sp_trace_setstatus 2, 0;
GO
EXEC sp_trace_setstatus 2, 2;
GO